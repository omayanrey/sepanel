  <footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>Version</b> 2.3.7
      </div>
      <strong>Copyright &copy; 2014-2016 <a href="https://github.com/wx1183618058/SoftEther-Netraffic">WX
      1183618058</a>.</strong> All rights
      reserved.
    </div>
    <!-- /.container -->
  </footer>