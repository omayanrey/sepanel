#!/bin/sh
cd /vpnserver
killall -9 cmdtool